/* eslint-disable import/prefer-default-export */
const closeForm = () => {
  window.location = '/';
};

export { closeForm };
